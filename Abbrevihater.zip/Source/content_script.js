function walk(rootNode) {
  // Find all the text nodes in rootNode
  var walker = document.createTreeWalker(
      rootNode,
      NodeFilter.SHOW_TEXT,
      null,
      false
    ),
    node;

  // Modify each text node's value
  while ((node = walker.nextNode())) {
    handleText(node);
  }
}

function formatSpan(spanText, toolTipText) {
  var newSpan = document.createElement('span');
  newSpan.style.backgroundColor = 'rgba(0,133,242,.1)';
  newSpan.style.cursor = 'pointer';
  newSpan.title = toolTipText;
  newSpan.textContent = spanText;
  return newSpan;
}

function handleText(textNode) {
  const oldText = textNode.nodeValue;
  const newText = replaceText(textNode.nodeValue);
  if (newText !== oldText) {
    const newSpan = formatSpan(newText, oldText);
    textNode.replaceWith(newSpan);
  }
}
function replaceText(v) {
  v = v.replace(/\b2WW\b/gi, '<two week wait>');
  v = v.replace(/\bBD\b/gi, '<insemination>');
  v = v.replace(/\bbaby dance\b/gi, '<insemination>');
  v = v.replace(/\bBCP\b/gi, '<birth control pills>');
  v = v.replace(/\bCD\b/gi, '<cycle day>');
  v = v.replace(/\bCM\b/gi, '<cervical mucus>');
  v = v.replace(/\bDPO\b/gi, '<days post ovulation>');
  v = v.replace(/\bTTC\b/gi, '<trying to conceive>');
  v = v.replace(/\bwifey\b/gi, '<my wife>');
  v = v.replace(/\bhubby\b/gi, '<my husband>');
  v = v.replace(/\bDW\b/gi, '<my wife>');
  v = v.replace(/\bDH\b/gi, '<my husband>');
  v = v.replace(/\bDS\b/gi, '<my son>');
  v = v.replace(/\bDD\b/gi, '<my daughter>');
  v = v.replace(/\bBFP\b/gi, '<positive pregnancy test>');
  v = v.replace(/\bBFN\b/gi, '<negative pregnancy test>');
  v = v.replace(/\bHB\b/gi, '<home birth>');
  v = v.replace(/\bLO\b/gi, '<child>');
  v = v.replace(/\bMC\b/gi, '<miscarriage>');
  v = v.replace(/\bMF\b/gi, '<male factor infertility>');
  v = v.replace(/\bMFI\b/gi, '<male factor infertility>');
  v = v.replace(/\bNTNP\b/gi, '<not trying, not preventing>');
  v = v.replace(/\bSA\b/gi, '<semen analysis>');
  v = v.replace(/\bSD\b/gi, '<sperm donor>');
  v = v.replace(/\bTWW\b/gi, '<two week wait>');
  v = v.replace(/\bM\/C\b/gi, '<miscarriage>');
  v = v.replace(/\bEWCM\b/gi, '<egg white cervical mucus>');
  v = v.replace(/\baunt flow\b/gi, '<period>');
  v = v.replace(/\bshark week\b/gi, '<period>');
  v = v.replace(/\bcrimson week\b/gi, '<period>');
  v = v.replace(/\baunt flow\b/gi, '<period>');
  v = v.replace(/\bpreggers\b/gi, '<pregnant>');
  v = v.replace(/\bpreggo\b/gi, '<pregnant>');
  v = v.replace(/\bbun in the over\b/gi, '<pregnant>');
  v = v.replace(/\beggies\b/gi, '<eggs>');
  v = v.replace(/\bembaby\b/gi, '<embryo>');
  v = v.replace(/\bembabies\b/gi, '<embryos>');
  v = v.replace(/\bsnow baby\b/gi, '<frozen embryo>');
  v = v.replace(/\bsnow babies\b/gi, '<frozen embryos>');
  v = v.replace(/\bpoas\b/gi, '<pee on a stick>');
  v = v.replace(/\blittle miracle\b/gi, '<baby>');
  v = v.replace(
    /\bpregnant until proven otherwise\b/gi,
    '<pee on a stick>'
  );
  v = v.replace(/\bpull the goalie\b/gi, '<go off birth control>');
  v = v.replace(
    /\bpulling the goalie\b/gi,
    '<going off birth control>'
  );
  v = v.replace(
    /\bpulled the goalie\b/gi,
    '<going off birth control>'
  );

  return v;
}

// Returns true if a node should *not* be altered in any way
function isForbiddenNode(node) {
  return (
    node.isContentEditable || // DraftJS and many others
    (node.parentNode && node.parentNode.isContentEditable) || // Special case for Gmail
    (node.tagName &&
      (node.tagName.toLowerCase() == 'textarea' || // Some catch-alls
        node.tagName.toLowerCase() == 'input'))
  );
}

// The callback used for the document body and title observers
function observerCallback(mutations) {
  var i, node;

  mutations.forEach(function (mutation) {
    for (i = 0; i < mutation.addedNodes.length; i++) {
      node = mutation.addedNodes[i];
      if (isForbiddenNode(node)) {
        // Should never operate on user-editable content
        continue;
      } else if (node.nodeType === 3) {
        // Replace the text for text nodes
        handleText(node);
      } else {
        // Otherwise, find text nodes within the given node and replace text
        walk(node);
      }
    }
  });
}

// Walk the doc (document) body, replace the title, and observe the body and title
function walkAndObserve(doc) {
  var docTitle = doc.getElementsByTagName('title')[0],
    observerConfig = {
      characterData: true,
      childList: true,
      subtree: true,
    },
    bodyObserver,
    titleObserver;

  // Do the initial text replacements in the document body and title
  walk(doc.body);
  doc.title = replaceText(doc.title);

  // Observe the body so that we replace text in any added/modified nodes
  bodyObserver = new MutationObserver(observerCallback);
  bodyObserver.observe(doc.body, observerConfig);

  // Observe the title so we can handle any modifications there
  if (docTitle) {
    titleObserver = new MutationObserver(observerCallback);
    titleObserver.observe(docTitle, observerConfig);
  }
}
walkAndObserve(document);
